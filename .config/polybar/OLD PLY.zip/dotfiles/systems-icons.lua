print "Copy the icon according to your system: "
print "                                                "
